let globalMaxZIndex = 2147483647;
const currentUrl = window.location.hostname + window.location.pathname;
const SAVE_DEBOUNCE_MS = 300;
const LOCAL_SAVE_IGNORE_MS = 500;
const FLOATING_BUTTON_POSITION_KEY = 'floatingButtonPosition';
const EDGE_BAR_SETTINGS_KEY = 'edgeReminderBarSettings';
const EDGE_BAR_ID = 'syncsticky-edge-reminder-bar';
const APP_SETTINGS_KEY = 'appSettings';
const RIGHT_SIDE_GAP = 12;
const EDGE_BAR_TOP = 90;
const RIGHT_SIDE_SPACING = 12;
const noteStore = SyncStickyNoteStore;
const noteUtils = SyncStickyNoteUtils;
const DEFAULT_TAB_ID = noteUtils.DEFAULT_TAB_ID;
const DEFAULT_NOTE_STATUS = noteUtils.DEFAULT_NOTE_STATUS;
let lastLocalSaveAt = 0;

window.addEventListener('load', () => {
  refreshFloatingButton();
  loadPageNotes();
  loadEdgeReminderBar();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (noteStore.hasNoteStorageChange(changes, area)) {
    if (Date.now() - lastLocalSaveAt >= LOCAL_SAVE_IGNORE_MS) {
      removeAllRenderedNotes();
      loadPageNotes();
    }
    loadEdgeReminderBar();
  }

  if (area === 'sync' && changes.boardSettings) {
    loadEdgeReminderBar();
  }

  if (area === 'sync' && changes.appSettings) {
    refreshFloatingButton();
  }
});

function removeAllRenderedNotes() {
  document.querySelectorAll('.sticky-note-card').forEach((card) => {
    if (typeof card.cleanupNote === 'function') {
      card.cleanupNote();
    }
    card.remove();
  });
}

function refreshFloatingButton() {
  chrome.storage.sync.get([APP_SETTINGS_KEY], (result) => {
    const settings = noteUtils.normalizeAppSettings(result[APP_SETTINGS_KEY]);
    const existing = document.getElementById('syncsticky-add-button');
    if (!settings.addButtonEnabled) {
      if (existing) existing.remove();
      return;
    }
    createFloatingButton();
  });
}

function createFloatingButton() {
  if (document.getElementById('syncsticky-add-button')) return;

  const btn = document.createElement('div');
  btn.id = 'syncsticky-add-button';
  btn.innerText = '+';
  btn.style.cssText = `
    position: fixed; width: 40px; height: 40px;
    background: rgba(0,0,0,0.5); color: white; border-radius: 50%;
    text-align: center; line-height: 38px; font-size: 24px; cursor: pointer;
    z-index: 2147483647; user-select: none; transition: background 0.3s;
  `;
  btn.title = 'Add sticky note';
  btn.onmouseover = () => btn.style.background = 'rgba(0,0,0,0.8)';
  btn.onmouseout = () => btn.style.background = 'rgba(0,0,0,0.5)';
  document.body.appendChild(btn);
  setupFloatingButtonPosition(btn);
}

function setupFloatingButtonPosition(btn) {
  const defaultPosition = getDefaultFloatingButtonPosition(btn);
  let currentPosition = defaultPosition;
  let lastViewportWidth = window.innerWidth;
  let lastViewportHeight = window.innerHeight;
  let wasDragged = false;
  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let initialLeft = 0;
  let initialTop = 0;

  chrome.storage.local.get([FLOATING_BUTTON_POSITION_KEY], (result) => {
    const savedPosition = result[FLOATING_BUTTON_POSITION_KEY];
    const position = restoreSnappedPosition(savedPosition, defaultPosition, btn);
    currentPosition = position;
    applyFloatingButtonPosition(btn, position);
  });

  btn.addEventListener('mousedown', (event) => {
    event.preventDefault();
    isDragging = true;
    wasDragged = false;
    startX = event.clientX;
    startY = event.clientY;
    initialLeft = btn.offsetLeft;
    initialTop = btn.offsetTop;
  });

  window.addEventListener('mousemove', (event) => {
    if (!isDragging) return;

    const nextPosition = normalizeFloatingButtonPosition({
      left: initialLeft + event.clientX - startX,
      top: initialTop + event.clientY - startY
    }, defaultPosition, btn);

    if (Math.abs(event.clientX - startX) > 3 || Math.abs(event.clientY - startY) > 3) {
      wasDragged = true;
    }
    applyFloatingButtonPosition(btn, nextPosition);
  });

  window.addEventListener('mouseup', () => {
    if (!isDragging) return;
    isDragging = false;

    const position = getSnappedPosition({
      left: btn.offsetLeft,
      top: btn.offsetTop
    }, btn);
    currentPosition = position;
    applyFloatingButtonPosition(btn, position);
    position.updatedAt = noteUtils.getTimestamp();
    chrome.storage.local.set({ [FLOATING_BUTTON_POSITION_KEY]: position });

    if (!wasDragged) {
      createNoteData(currentUrl);
    }
  });

  window.addEventListener('resize', () => {
    const position = restoreSnappedPosition(getResponsiveResizePosition({
      ...currentPosition,
      left: btn.offsetLeft,
      top: btn.offsetTop
    }, btn, lastViewportWidth, lastViewportHeight), defaultPosition, btn);
    currentPosition = position;
    lastViewportWidth = window.innerWidth;
    lastViewportHeight = window.innerHeight;
    position.updatedAt = noteUtils.getTimestamp();
    applyFloatingButtonPosition(btn, position);
    chrome.storage.local.set({ [FLOATING_BUTTON_POSITION_KEY]: position });
  });
}

function resultEdgeFromElement(element) {
  return getSnappedPosition({
    left: element.offsetLeft,
    top: element.offsetTop
  }, element).edge;
}

function resultVerticalAnchorFromElement(element) {
  return getSnappedPosition({
    left: element.offsetLeft,
    top: element.offsetTop
  }, element).verticalAnchor;
}

function getDefaultFloatingButtonPosition(btn) {
  return {
    left: window.innerWidth - getElementDimension(btn, 'width') - RIGHT_SIDE_GAP,
    top: getRightSideBottomTop(btn),
    edge: 'right',
    verticalAnchor: 'bottom'
  };
}

function normalizeFloatingButtonPosition(position, fallbackPosition, element) {
  const rawLeft = Number.isFinite(position?.left) ? position.left : fallbackPosition.left;
  const rawTop = Number.isFinite(position?.top) ? position.top : fallbackPosition.top;
  const elementWidth = getElementDimension(element, 'width');
  const elementHeight = getElementDimension(element, 'height');
  return {
    left: Math.min(Math.max(rawLeft, 0), Math.max(window.innerWidth - elementWidth, 0)),
    top: Math.min(Math.max(rawTop, 0), Math.max(window.innerHeight - elementHeight, 0))
  };
}

function getElementDimension(element, property) {
  const offsetValue = property === 'width' ? element.offsetWidth : element.offsetHeight;
  if (offsetValue > 0) return offsetValue;
  const styleValue = parseInt(element.style[property], 10);
  return Number.isFinite(styleValue) && styleValue > 0 ? styleValue : 0;
}

function getSnappedPosition(position, element) {
  const normalized = normalizeFloatingButtonPosition(position, position, element);
  const maxLeft = Math.max(window.innerWidth - getElementDimension(element, 'width'), 0);
  const maxTop = Math.max(window.innerHeight - getElementDimension(element, 'height'), 0);
  const distances = [
    { edge: 'left', value: normalized.left },
    { edge: 'right', value: maxLeft - normalized.left },
    { edge: 'top', value: normalized.top },
    { edge: 'bottom', value: maxTop - normalized.top }
  ];
  const nearest = distances.reduce((closest, item) => (
    item.value < closest.value ? item : closest
  ), distances[0]);

  if (nearest.edge === 'left') return { ...normalized, left: 0, edge: nearest.edge, verticalAnchor: getVerticalAnchor(normalized, element) };
  if (nearest.edge === 'right') return { ...normalized, left: maxLeft, edge: nearest.edge, verticalAnchor: getVerticalAnchor(normalized, element) };
  if (nearest.edge === 'top') return { ...normalized, top: 0, edge: nearest.edge };
  return { ...normalized, top: maxTop, edge: nearest.edge };
}

function restoreSnappedPosition(position, fallbackPosition, element) {
  const normalized = normalizeFloatingButtonPosition(position, fallbackPosition, element);
  const maxLeft = Math.max(window.innerWidth - getElementDimension(element, 'width'), 0);
  const maxTop = Math.max(window.innerHeight - getElementDimension(element, 'height'), 0);

  if (position?.edge === 'left') return applyVerticalAnchor({ ...normalized, left: 0, edge: 'left' }, position, element);
  if (position?.edge === 'right') return applyVerticalAnchor({ ...normalized, left: maxLeft, edge: 'right' }, position, element);
  if (position?.edge === 'top') return { ...normalized, top: 0, edge: 'top' };
  if (position?.edge === 'bottom') return { ...normalized, top: maxTop, edge: 'bottom' };
  return getSnappedPosition(normalized, element);
}

function getVerticalAnchor(position, element) {
  const maxTop = Math.max(window.innerHeight - getElementDimension(element, 'height'), 0);
  return position.top > maxTop / 2 ? 'bottom' : 'top';
}

function applyVerticalAnchor(restoredPosition, originalPosition, element) {
  if (originalPosition?.verticalAnchor === 'bottom') {
    return {
      ...restoredPosition,
      top: getRightSideBottomTop(element),
      verticalAnchor: 'bottom'
    };
  }
  if (originalPosition?.verticalAnchor === 'top') {
    return {
      ...restoredPosition,
      top: Math.min(Math.max(originalPosition.top, 0), Math.max(window.innerHeight - getElementDimension(element, 'height'), 0)),
      verticalAnchor: 'top'
    };
  }
  return {
    ...restoredPosition,
    verticalAnchor: getVerticalAnchor(restoredPosition, element)
  };
}

function getRightSideBottomTop(element) {
  return Math.max(window.innerHeight - getElementDimension(element, 'height') - RIGHT_SIDE_GAP, 0);
}

function getResponsiveResizePosition(position, element, previousWidth, previousHeight) {
  if (position.edge !== 'left' && position.edge !== 'right') return position;
  if (position.verticalAnchor === 'top' || position.verticalAnchor === 'bottom') return position;

  const previousMaxTop = Math.max(previousHeight - getElementDimension(element, 'height'), 1);
  const nextMaxTop = Math.max(window.innerHeight - getElementDimension(element, 'height'), 0);
  return {
    ...position,
    top: Math.min(Math.max((position.top / previousMaxTop) * nextMaxTop, 0), nextMaxTop)
  };
}

function applyFloatingButtonPosition(element, position) {
  element.style.left = `${position.left}px`;
  element.style.top = `${position.top}px`;
}

function getBoundedFixedPosition(position, element) {
  return normalizeFloatingButtonPosition(position, position, element);
}

function loadEdgeReminderBar() {
  Promise.all([
    noteStore.loadNotes(),
    new Promise((resolve) => chrome.storage.sync.get(['boardSettings'], resolve))
  ]).then(([notes, syncResult]) => {
    const groups = getEdgeReminderGroups(notes, syncResult.boardSettings);
    chrome.storage.local.get([EDGE_BAR_SETTINGS_KEY], (localResult) => {
      const settings = normalizeEdgeBarSettings(localResult[EDGE_BAR_SETTINGS_KEY]);
      renderEdgeReminderBar(groups, settings);
    });
  }).catch(() => {});
}

function getEdgeReminderGroups(notes, boardSettings) {
  const tabs = Array.isArray(boardSettings?.tabs) && boardSettings.tabs.length
    ? boardSettings.tabs
    : [{ id: DEFAULT_TAB_ID, label: 'Default', statuses: [{ id: DEFAULT_NOTE_STATUS, label: 'Discussion', color: '#c98219' }] }];
  const groups = new Map();
  notes.map(noteUtils.normalizeNote)
    .filter((note) => note.edgeReminder)
    .forEach((note) => {
      const tab = tabs.find((item) => item.id === note.tabId) || tabs[0];
      const statuses = Array.isArray(tab.statuses) && tab.statuses.length ? tab.statuses : tabs[0].statuses;
      const status = statuses.find((item) => item.id === note.status) || statuses[0];
      if (!status) return;
      const key = `${tab.id}:${status.id}`;
      const existing = groups.get(key) || {
        tabId: tab.id,
        tabLabel: tab.label || 'Default',
        statusId: status.id,
        statusLabel: typeof status.label === 'string' ? status.label : '',
        color: noteUtils.isHexColor(status.color) ? status.color : '#c98219',
        count: 0
      };
      existing.count += 1;
      groups.set(key, existing);
    });
  return Array.from(groups.values());
}

function normalizeEdgeBarSettings(settings) {
  return {
    left: Number.isFinite(settings?.left) ? settings.left : window.innerWidth - 50,
    top: Number.isFinite(settings?.top) ? settings.top : EDGE_BAR_TOP,
    edge: typeof settings?.edge === 'string' ? settings.edge : 'right',
    verticalAnchor: typeof settings?.verticalAnchor === 'string' ? settings.verticalAnchor : 'top',
    opacity: Number.isFinite(settings?.opacity) ? Math.min(Math.max(settings.opacity, 0.2), 1) : 0.82
  };
}

function saveEdgeBarSettings(settings) {
  settings.updatedAt = noteUtils.getTimestamp();
  chrome.storage.local.set({ [EDGE_BAR_SETTINGS_KEY]: settings });
}

function renderEdgeReminderBar(groups, settings) {
  const existing = document.getElementById(EDGE_BAR_ID);
  if (!groups.length) {
    if (existing) existing.remove();
    return;
  }

  const bar = existing || document.createElement('div');
  const position = restoreSnappedPosition(settings, {
    left: window.innerWidth - 50,
    top: EDGE_BAR_TOP,
    edge: 'right',
    verticalAnchor: 'top'
  }, bar);
  const addButton = document.getElementById('syncsticky-add-button');
  const addButtonHeight = addButton ? getElementDimension(addButton, 'height') : 40;
  const maxBarHeight = Math.max(window.innerHeight - position.top - addButtonHeight - RIGHT_SIDE_GAP - RIGHT_SIDE_SPACING, 80);
  bar.id = EDGE_BAR_ID;
  bar.innerHTML = '';
  bar.style.cssText = `
    position: fixed;
    left: ${position.left}px;
    top: ${position.top}px;
    z-index: 2147483646;
    display: flex;
    flex-direction: column;
    gap: 5px;
    width: 42px;
    max-height: ${maxBarHeight}px;
    padding: 6px 4px;
    border-radius: 8px;
    background: rgba(20,22,20,${settings.opacity * 0.54});
    box-shadow: 0 10px 24px rgba(0,0,0,0.22);
    cursor: grab;
    user-select: none;
    overflow-y: auto;
    color-scheme: light;
    font-family: "Bahnschrift", "Aptos", "Segoe UI", sans-serif;
  `;
  bar.title = 'SyncSticky edge reminders';

  groups.forEach((group) => {
    const item = document.createElement('div');
    item.style.cssText = `
      min-height: 32px;
      border-radius: 6px;
      background: ${group.color};
      color: #1f2320;
      border: 1px solid rgba(31,35,32,0.18);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 1px;
      font-weight: 900;
      opacity: ${settings.opacity};
      box-shadow: inset 0 0 0 1px rgba(255,255,255,0.32);
      overflow: hidden;
    `;
    const count = document.createElement('span');
    count.style.cssText = 'font-size: 12px; line-height: 1;';
    count.innerText = String(group.count);

    const label = document.createElement('span');
    label.style.cssText = 'max-width: 34px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 8px; line-height: 1;';
    label.innerText = group.tabLabel;

    item.appendChild(count);
    item.appendChild(label);
    item.title = `${group.tabLabel}/${group.statusLabel}: ${group.count} reminder item(s)`;
    bar.appendChild(item);
  });

  const opacityInput = document.createElement('input');
  opacityInput.type = 'range';
  opacityInput.min = '0.2';
  opacityInput.max = '1';
  opacityInput.step = '0.05';
  opacityInput.value = String(settings.opacity);
  opacityInput.title = 'Opacity';
  opacityInput.style.cssText = `
    width: 40px;
    height: 18px;
    margin: 2px 0 0;
    accent-color: #0f766e;
    cursor: pointer;
  `;
  opacityInput.onmousedown = (event) => event.stopPropagation();
  opacityInput.oninput = () => {
    settings.opacity = Number(opacityInput.value);
    saveEdgeBarSettings(settings);
    loadEdgeReminderBar();
  };
  bar.appendChild(opacityInput);

  if (!existing) {
    document.body.appendChild(bar);
    const snappedPosition = restoreSnappedPosition(settings, {
      left: window.innerWidth - bar.offsetWidth,
      top: EDGE_BAR_TOP,
      edge: 'right',
      verticalAnchor: 'top'
    }, bar);
    applyFloatingButtonPosition(bar, snappedPosition);
    settings.left = snappedPosition.left;
    settings.top = snappedPosition.top;
    settings.edge = snappedPosition.edge;
    settings.verticalAnchor = snappedPosition.verticalAnchor;
    setupEdgeBarDrag(bar, settings);
  }
}

function setupEdgeBarDrag(bar, settings) {
  let currentPosition = {
    left: settings.left,
    top: settings.top,
    edge: settings.edge,
    verticalAnchor: settings.verticalAnchor
  };
  let lastViewportWidth = window.innerWidth;
  let lastViewportHeight = window.innerHeight;
  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let initialLeft = 0;
  let initialTop = 0;

  bar.addEventListener('mousedown', (event) => {
    if (event.target.tagName === 'INPUT') return;
    isDragging = true;
    startX = event.clientX;
    startY = event.clientY;
    initialLeft = bar.offsetLeft;
    initialTop = bar.offsetTop;
    bar.style.cursor = 'grabbing';
  });

  window.addEventListener('mousemove', (event) => {
    if (!isDragging) return;
    const nextLeft = Math.min(Math.max(initialLeft + event.clientX - startX, 0), window.innerWidth - bar.offsetWidth);
    const nextTop = Math.min(Math.max(initialTop + event.clientY - startY, 0), window.innerHeight - bar.offsetHeight);
    bar.style.left = `${nextLeft}px`;
    bar.style.top = `${nextTop}px`;
  });

  window.addEventListener('mouseup', () => {
    if (!isDragging) return;
    isDragging = false;
    bar.style.cursor = 'grab';
    const snappedPosition = getSnappedPosition({
      left: bar.offsetLeft,
      top: bar.offsetTop
    }, bar);
    applyFloatingButtonPosition(bar, snappedPosition);
    settings.left = snappedPosition.left;
    settings.top = snappedPosition.top;
    settings.edge = snappedPosition.edge;
    settings.verticalAnchor = snappedPosition.verticalAnchor;
    currentPosition = snappedPosition;
    saveEdgeBarSettings(settings);
  });

  window.addEventListener('resize', () => {
    const fallbackPosition = {
      left: window.innerWidth - 50,
      top: EDGE_BAR_TOP,
      edge: 'right',
      verticalAnchor: 'top'
    };
    const resizePosition = getResponsiveResizePosition({
      ...currentPosition,
      left: bar.offsetLeft,
      top: bar.offsetTop
    }, bar, lastViewportWidth, lastViewportHeight);
    const nextSettings = restoreSnappedPosition(resizePosition, fallbackPosition, bar);
    currentPosition = nextSettings;
    lastViewportWidth = window.innerWidth;
    lastViewportHeight = window.innerHeight;
    saveEdgeBarSettings(nextSettings);
    loadEdgeReminderBar();
  });
}

function loadPageNotes() {
  noteStore.loadNotes().then((notes) => {
    const pageNotes = notes.filter((note) => note.url === currentUrl);
    pageNotes.forEach((note) => renderNote(noteUtils.normalizeNote(note)));
  }).catch(() => {});
}

function createNoteData(targetUrl) {
  chrome.storage.sync.get(['boardSettings'], (result) => {
    const tabs = result.boardSettings?.tabs || [];
    const activeTab = tabs.find((tab) => tab.id === result.boardSettings?.activeTabId) || tabs[0];
    const firstTab = activeTab?.id || DEFAULT_TAB_ID;
    const firstStatus = activeTab?.statuses?.[0]?.id || result.boardSettings?.statuses?.[0]?.id || DEFAULT_NOTE_STATUS;
    const newNote = {
      id: Date.now().toString(),
      content: '',
      x: 100 + Math.random() * 50,
      y: 100 + Math.random() * 50,
      width: 250,
      height: 250,
      color: '#fff7b1',
      url: targetUrl,
      reminder: '',
      zIndex: 10000,
      status: firstStatus,
      tabId: firstTab,
      edgeReminder: false,
      minimized: false,
      minimizedX: 12,
      minimizedY: 12,
      updatedAt: noteUtils.getTimestamp()
    };
    saveNoteToStorage(newNote);
    renderNote(newNote);
  });
}

function saveNoteToStorage(noteData) {
  lastLocalSaveAt = Date.now();
  const normalizedNote = noteUtils.normalizeNote(noteData);
  normalizedNote.updatedAt = noteUtils.getTimestamp();
  noteStore.saveNote(normalizedNote).catch((error) => {
    console.warn(`Could not save note: ${error.message}`);
  });
}

function deleteNoteFromStorage(id) {
  lastLocalSaveAt = Date.now();
  noteUtils.clearReminder(id);
  noteStore.removeNote(id).catch((error) => {
    console.warn(`Could not delete note: ${error.message}`);
  });
}

function getNoteSummary(data) {
  const summary = (data.content || '').trim().replace(/\s+/g, ' ');
  return summary ? summary.slice(0, 24) : 'Empty note';
}

function renderNote(noteData) {
  const data = noteUtils.normalizeNote(noteData);
  if (document.getElementById(data.id)) return;

  if (data.minimized) {
    renderMinimizedNote(data);
  } else {
    renderExpandedNote(data);
  }
}

function renderMinimizedNote(data) {
  let isDeleted = false;
  const card = document.createElement('div');
  card.className = 'sticky-note-card sticky-note-minimized';
  card.id = data.id;
  const initialPosition = getBoundedFixedPosition({
    left: data.minimizedX,
    top: data.minimizedY
  }, card);
  card.style.left = `${initialPosition.left}px`;
  card.style.top = `${initialPosition.top}px`;
  card.style.backgroundColor = data.color;
  card.style.position = 'fixed';
  card.style.zIndex = data.zIndex || 10000;
  card.title = 'Drag to move. Double-click to restore.';

  const summary = document.createElement('span');
  summary.className = 'minimized-note-summary';
  summary.innerText = getNoteSummary(data);

  const restoreBtn = document.createElement('button');
  restoreBtn.type = 'button';
  restoreBtn.className = 'note-icon-btn';
  restoreBtn.innerText = '+';
  restoreBtn.title = 'Restore note';
  restoreBtn.onclick = (event) => {
    event.stopPropagation();
    isDeleted = true;
    data.minimized = false;
    card.remove();
    saveNoteToStorage(data);
    renderExpandedNote(data);
  };

  card.appendChild(summary);
  card.appendChild(restoreBtn);
  document.body.appendChild(card);
  const boundedPosition = getBoundedFixedPosition({
    left: card.offsetLeft,
    top: card.offsetTop
  }, card);
  applyFloatingButtonPosition(card, boundedPosition);
  data.minimizedX = boundedPosition.left;
  data.minimizedY = boundedPosition.top;

  setupMinimizedNoteDrag(card, data, () => isDeleted);

  card.ondblclick = () => {
    if (isDeleted) return;
    isDeleted = true;
    data.minimized = false;
    card.remove();
    saveNoteToStorage(data);
    renderExpandedNote(data);
  };

  card.cleanupNote = () => {
    isDeleted = true;
  };

  window.addEventListener('resize', () => {
    if (isDeleted) return;
    const position = getBoundedFixedPosition({
      left: card.offsetLeft,
      top: card.offsetTop
    }, card);
    applyFloatingButtonPosition(card, position);
    data.minimizedX = position.left;
    data.minimizedY = position.top;
    saveNoteToStorage(data);
  });
}

function setupMinimizedNoteDrag(card, data, getIsDeleted) {
  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let initialLeft = 0;
  let initialTop = 0;

  card.addEventListener('mousedown', (event) => {
    if (event.target.closest('button')) return;
    isDragging = true;
    startX = event.clientX;
    startY = event.clientY;
    initialLeft = card.offsetLeft;
    initialTop = card.offsetTop;
    globalMaxZIndex++;
    card.style.zIndex = globalMaxZIndex;
    data.zIndex = globalMaxZIndex;
  });

  window.addEventListener('mousemove', (event) => {
    if (!isDragging || getIsDeleted()) return;
    const position = normalizeFloatingButtonPosition({
      left: initialLeft + event.clientX - startX,
      top: initialTop + event.clientY - startY
    }, { left: 12, top: 12 }, card);
    applyFloatingButtonPosition(card, position);
  });

  window.addEventListener('mouseup', () => {
    if (!isDragging || getIsDeleted()) return;
    isDragging = false;
    data.minimizedX = parseInt(card.style.left, 10);
    data.minimizedY = parseInt(card.style.top, 10);
    saveNoteToStorage(data);
  });
}

function renderExpandedNote(data) {
  let isDeleted = false;
  let resizeObserver;
  let timerInterval;
  let hasObservedInitialSize = false;

  const card = document.createElement('div');
  card.className = 'sticky-note-card';
  card.id = data.id;
  card.style.width = `${data.width}px`;
  card.style.height = `${data.height}px`;
  const initialPosition = getBoundedFixedPosition({
    left: data.x,
    top: data.y
  }, card);
  card.style.left = `${initialPosition.left}px`;
  card.style.top = `${initialPosition.top}px`;
  card.style.backgroundColor = data.color;
  card.style.position = 'fixed';
  card.style.zIndex = data.zIndex || 10000;

  const saveSize = noteUtils.debounce(() => {
    if (!isDeleted) saveNoteToStorage(data);
  }, SAVE_DEBOUNCE_MS);

  card.cleanupNote = () => {
    isDeleted = true;
    clearInterval(timerInterval);
    if (resizeObserver) resizeObserver.disconnect();
  };

  card.onmousedown = () => {
    globalMaxZIndex++;
    card.style.zIndex = globalMaxZIndex;
    data.zIndex = globalMaxZIndex;
    saveNoteToStorage(data);
  };

  const header = document.createElement('div');
  header.className = 'sticky-header';

  const leftControls = document.createElement('div');
  leftControls.style.display = 'flex';

  const colorInput = document.createElement('input');
  colorInput.type = 'color';
  colorInput.value = data.color;
  colorInput.title = 'Note color';
  colorInput.style.cssText = 'width: 20px; height: 20px; border: none; cursor: pointer; margin-right: 5px;';
  colorInput.onmousedown = (event) => event.stopPropagation();
  colorInput.oninput = (event) => {
    card.style.backgroundColor = event.target.value;
    data.color = event.target.value;
    if (!isDeleted) saveNoteToStorage(data);
  };
  leftControls.appendChild(colorInput);

  const minimizeBtn = document.createElement('span');
  minimizeBtn.innerText = '_';
  minimizeBtn.title = 'Minimize note';
  minimizeBtn.className = 'close-btn';
  minimizeBtn.onmousedown = (event) => event.stopPropagation();
  minimizeBtn.onclick = () => {
    isDeleted = true;
    clearInterval(timerInterval);
    if (resizeObserver) resizeObserver.disconnect();
    data.minimized = true;
    data.minimizedX = Number.isFinite(data.minimizedX) ? data.minimizedX : 12;
    data.minimizedY = Number.isFinite(data.minimizedY) ? data.minimizedY : 12;
    card.remove();
    saveNoteToStorage(data);
    renderMinimizedNote(data);
  };

  const closeBtn = document.createElement('span');
  closeBtn.innerText = 'x';
  closeBtn.title = 'Delete note';
  closeBtn.className = 'close-btn';
  closeBtn.onmousedown = (event) => event.stopPropagation();
  closeBtn.onclick = () => {
    card.cleanupNote();
    card.remove();
    deleteNoteFromStorage(data.id);
  };

  const rightControls = document.createElement('div');
  rightControls.style.display = 'flex';
  rightControls.appendChild(minimizeBtn);
  rightControls.appendChild(closeBtn);

  header.appendChild(leftControls);
  header.appendChild(rightControls);

  const content = document.createElement('div');
  content.className = 'sticky-content';
  content.contentEditable = true;
  content.innerHTML = noteUtils.getNoteHtml(data);

  content.addEventListener('mousedown', (event) => {
    if (event.target.tagName === 'A') {
      event.preventDefault();
      event.stopImmediatePropagation();
      noteUtils.openSafeUrl(event.target.href);
    }
  });

  content.addEventListener('focus', () => {
    content.innerText = noteUtils.stripHtml(content.innerHTML);
  });

  content.addEventListener('blur', () => {
    if (isDeleted) return;
    data.content = content.innerText;
    saveNoteToStorage(data);
    content.innerHTML = noteUtils.linkify(data.content);
  });

  const footer = document.createElement('div');
  footer.className = 'sticky-footer';

  const reminderButton = document.createElement('button');
  reminderButton.type = 'button';
  reminderButton.className = `sticky-reminder-btn${data.reminder ? ' active' : ''}`;
  reminderButton.innerText = data.reminder ? 'A!' : 'A';
  reminderButton.title = data.reminder ? `Reminder: ${noteUtils.getCountdownText(data.reminder) || data.reminder}` : 'Set reminder';
  reminderButton.onmousedown = (event) => event.stopPropagation();

  const reminderPanel = document.createElement('div');
  reminderPanel.className = 'sticky-reminder-panel';
  reminderPanel.hidden = true;

  const dateInput = document.createElement('input');
  dateInput.type = 'datetime-local';
  dateInput.className = 'date-picker';
  dateInput.title = 'Reminder time';
  dateInput.value = data.reminder || '';
  dateInput.onmousedown = (event) => event.stopPropagation();

  const clearReminderBtn = document.createElement('button');
  clearReminderBtn.type = 'button';
  clearReminderBtn.className = 'sticky-reminder-clear';
  clearReminderBtn.innerText = 'Clear';
  clearReminderBtn.disabled = !data.reminder;
  clearReminderBtn.onmousedown = (event) => event.stopPropagation();

  const countdownDiv = document.createElement('div');
  countdownDiv.className = 'countdown-text';

  const updateTimer = () => {
    countdownDiv.innerText = noteUtils.getCountdownText(dateInput.value);
    reminderButton.classList.toggle('active', Boolean(dateInput.value));
    reminderButton.innerText = dateInput.value ? 'A!' : 'A';
    reminderButton.title = dateInput.value ? `Reminder: ${countdownDiv.innerText || dateInput.value}` : 'Set reminder';
    clearReminderBtn.disabled = !dateInput.value;
  };

  updateTimer();
  timerInterval = setInterval(updateTimer, 60000);

  reminderButton.onclick = (event) => {
    event.stopPropagation();
    reminderPanel.hidden = !reminderPanel.hidden;
  };

  dateInput.onchange = () => {
    if (isDeleted) return;
    data.reminder = dateInput.value;
    saveNoteToStorage(data);
    updateTimer();

    if (data.reminder) {
      noteUtils.scheduleReminder(data);
    } else {
      noteUtils.clearReminder(data.id);
    }
  };

  clearReminderBtn.onclick = () => {
    if (isDeleted) return;
    dateInput.value = '';
    data.reminder = '';
    saveNoteToStorage(data);
    noteUtils.clearReminder(data.id);
    updateTimer();
  };

  reminderPanel.appendChild(dateInput);
  reminderPanel.appendChild(clearReminderBtn);
  reminderPanel.appendChild(countdownDiv);
  footer.appendChild(reminderButton);
  footer.appendChild(reminderPanel);

  card.appendChild(header);
  card.appendChild(content);
  card.appendChild(footer);
  document.body.appendChild(card);

  let isDragging = false;
  let startX;
  let startY;
  let initialLeft;
  let initialTop;

  header.addEventListener('mousedown', (event) => {
    if (event.target !== header) return;
    isDragging = true;
    startX = event.clientX;
    startY = event.clientY;
    initialLeft = card.offsetLeft;
    initialTop = card.offsetTop;
  });

  window.addEventListener('mousemove', (event) => {
    if (!isDragging) return;
    const position = getBoundedFixedPosition({
      left: initialLeft + event.clientX - startX,
      top: initialTop + event.clientY - startY
    }, card);
    applyFloatingButtonPosition(card, position);
  });

  window.addEventListener('mouseup', () => {
    if (!isDragging) return;
    isDragging = false;
    data.x = parseInt(card.style.left, 10);
    data.y = parseInt(card.style.top, 10);
    saveNoteToStorage(data);
  });

  resizeObserver = new ResizeObserver(() => {
    if (isDeleted) return;
    if (!hasObservedInitialSize) {
      hasObservedInitialSize = true;
      return;
    }
    data.width = parseInt(card.style.width, 10);
    data.height = parseInt(card.style.height, 10);
    const position = getBoundedFixedPosition({
      left: card.offsetLeft,
      top: card.offsetTop
    }, card);
    applyFloatingButtonPosition(card, position);
    data.x = position.left;
    data.y = position.top;
    saveSize();
  });
  resizeObserver.observe(card);

  window.addEventListener('resize', () => {
    if (isDeleted) return;
    const position = getBoundedFixedPosition({
      left: card.offsetLeft,
      top: card.offsetTop
    }, card);
    applyFloatingButtonPosition(card, position);
    data.x = position.left;
    data.y = position.top;
    saveNoteToStorage(data);
  });
}